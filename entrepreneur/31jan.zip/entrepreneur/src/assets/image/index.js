import logo from "./elegant_enterprenures.jpg"
import asset1 from "./asset1.jpeg"
import asset2 from "./asset2.jpeg"
import asset3 from "./Nation-Building.jpg"

export {
    logo,
    asset1,
    asset2,
    asset3
}